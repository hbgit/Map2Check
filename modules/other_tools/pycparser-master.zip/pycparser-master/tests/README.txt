Run 'python tests/all_tests.py' from the root pycparser directory
